﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form5 : Form
    {
        Model1 db = new Model1();
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            Model1 db = new Model1();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" ||
  textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "")
            {
                MessageBox.Show("Нужно задать все данные!");
                return;
            }
            if (textBox2.Text != textBox3.Text)
            {
                MessageBox.Show("Значения паролей не совпадают!");
                return;
            }
            if ((textBox5.Text != "Покупатель") && (textBox5.Text != "Продавец") && (textBox5.Text != "Менеджер"))
            {
                MessageBox.Show("Задана неверная роль!");
                return;
            }

            // ищем запись пользователя с введенным логином
            Пользователи usr = db.Пользователи.Find(textBox1.Text);
            // если такой пользователь есть и его пароль правильный
            if (usr != null)
            {
                MessageBox.Show("Пользователь с таким логином уже есть!");
                return;
            }
            // создаем нового пользователя
            usr = new Пользователи();
            usr.Логин = textBox1.Text;
            usr.Пароль = textBox2.Text;
            usr.Роль = textBox5.Text;
            usr.Имя = textBox4.Text;
            usr.ДатаРождения = null;
            usr.Фамилия = null;
            usr.Отчество = null;
            usr.НомерТелефона = null;
            usr.ЭлектронныйАдрес = null;
            usr.Фото = null;
            // добавляем новую учетную запись в коллекцию
            db.Пользователи.Add(usr);
            try
            {
                // сохраняем нового пользователя в базе данных
                db.SaveChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            MessageBox.Show("Пользователь " + usr.Логин + "зарегистрирован!");
            Form1 f = new Form1();
            f.Show();
            this.Close();
            return;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Close();
        }
    }
}

