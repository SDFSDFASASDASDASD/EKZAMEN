﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public static Пользователи USER { get; set; }
        Model1 db = new Model1();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // проверяем, что в текстовые поля введены данные
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("Нужно задать логин и пароль!");
                return;
            }

            // ищем запись пользователя с введенным логином
            Пользователи usr = db.Пользователи.Find(textBox1.Text);

            // если такой пользователь есть и его пароль совпадает с введенным
            if ((usr != null) && (usr.Пароль == textBox2.Text))
            {
                // сохраняем данные пользователя в статической переменной
                // для использования данных пользователя в других формах
                USER = usr;

                // проверяем роль пользователя
                // если роль = «Директор», то вызываем форму Директора
                if (usr.Роль == "Покупатель")
                {
                    // создаем форму директора
                    Form4 frm = new Form4();
                    // показываем форму директора
                    frm.Show();
                    //  форму подключения скрываем (но не закрываем!)
                    this.Hide();
                }
                // если роль = «Менеджер», то вызываем форму Менеджера
                else if (usr.Роль == "Менеджер")
                {
                    // создаем форму менеджера
                    Form2 frm = new Form2();
                    // показываем форму менеджера
                    frm.Show();
                    // начальную форму подключения скрываем (но не закрываем!)
                    this.Hide();
                }
                else if (usr.Роль == "Продавец")
                {
                    // создаем форму администратора
                    Form3 frm = new Form3();
                    // показываем форму администратора
                    frm.Show();
                    // начальную форму подключения скрываем (но не закрываем!)
                    this.Hide();
                }
                else // если такой роли нет
                {
                    // если данные введены не правильно, то показываем сообщение
                    MessageBox.Show($"Роли {usr.Роль} в системе нет!");
                    return;
                }
            }
            else
            {
                // если данные введены не правильно, то показываем сообщение
                MessageBox.Show("Пользователя с таким логином и паролем нет!");
                return;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form5 f = new Form5();
            f.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}



